---
title: Enterprise RAG
emoji: 📚
colorFrom: indigo
colorTo: purple
sdk: docker
pinned: false
license: mit
app_port: 7860
---

# 📚 Enterprise RAG Platform

PDF-based Retrieval-Augmented Generation system with semantic search and source highlighting.

## Features

- 📄 **PDF Upload** - Process documents with automatic chunking
- 🔍 **Semantic Search** - Find relevant content using embeddings  
- 💬 **AI Q&A** - Get answers grounded in your documents
- 📍 **Source Highlighting** - See exactly where answers come from
- 📑 **Multi-doc Filtering** - Query specific documents or all

## Quick Start

1. Upload PDFs using the sidebar
2. Select documents to query
3. Ask questions in the chat
4. Click source chips to view context

## Required Secrets

Add in **Settings → Variables and secrets**:

| Secret | Required | Get it from |
|--------|----------|-------------|
| `GROQ_API_KEY` | ✅ Yes | [console.groq.com](https://console.groq.com) (free) |

## Optional Secrets

| Secret | Description |
|--------|-------------|
| `QDRANT_URL` | Qdrant Cloud URL for persistent storage |
| `QDRANT_API_KEY` | Qdrant Cloud API key |
| `OPENAI_API_KEY` | Alternative LLM provider |
| `LLM_PROVIDER` | `groq` (default), `openai`, `anthropic`, `google` |

## ⚠️ Important Notes

- **Data Persistence**: By default, uploaded documents are stored in-memory and will be **lost when the Space restarts**. For persistent storage, use [Qdrant Cloud](https://cloud.qdrant.io) (free tier available).

- **API Usage**: This app uses LLM APIs which have rate limits. The free Groq tier is sufficient for personal use.

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/ingest` | POST | Upload PDF |
| `/ingest/documents` | GET | List documents |
| `/query/ask` | POST | RAG Q&A |
| `/query/search` | POST | Semantic search |
| `/health` | GET | Health check |

## Links

- [Full Documentation](https://github.com/yourusername/enterprise-rag)
- [API Reference](https://github.com/yourusername/enterprise-rag/blob/main/docs/API.md)
- [Report Issues](https://github.com/yourusername/enterprise-rag/issues)

---

Made with ❤️ using FastAPI, Qdrant, and Sentence Transformers
