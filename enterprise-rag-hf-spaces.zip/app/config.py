"""Application configuration with HF Spaces support."""

import os
from functools import lru_cache
from typing import Optional

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings."""

    # App
    app_name: str = "Enterprise RAG"
    app_version: str = "1.0.0"
    debug: bool = False

    # API Security
    api_key: Optional[str] = None  # Optional API key protection

    # CORS
    cors_origins: str = "*"

    # Qdrant - defaults to in-memory for HF Spaces
    qdrant_host: str = "localhost"
    qdrant_port: int = 6333
    qdrant_api_key: Optional[str] = None
    qdrant_url: Optional[str] = None  # For Qdrant Cloud
    qdrant_in_memory: bool = True  # Use in-memory by default for HF Spaces
    collection_name: str = "rag_documents"

    # Embeddings
    embedding_model: str = "all-MiniLM-L6-v2"
    embedding_dimension: int = 384

    # Chunking
    chunk_size: int = 512
    chunk_overlap: int = 50

    # LLM
    llm_provider: str = "groq"  # groq has free tier
    llm_model: Optional[str] = None
    llm_temperature: float = 0.3

    # Provider API Keys
    openai_api_key: Optional[str] = None
    anthropic_api_key: Optional[str] = None
    google_api_key: Optional[str] = None
    groq_api_key: Optional[str] = None

    @property
    def cors_origins_list(self) -> list[str]:
        if self.cors_origins == "*":
            return ["*"]
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"


@lru_cache
def get_settings() -> Settings:
    return Settings()
