# 📚 API Reference

Complete API documentation for Enterprise RAG Platform.

**Base URL:** `http://localhost:7860` (or your deployment URL)

**Authentication:** Optional API key via `X-API-Key` header

---

## Table of Contents

- [Ingestion API](#ingestion-api)
- [Query API](#query-api)
- [Health API](#health-api)
- [Error Handling](#error-handling)
- [Rate Limiting](#rate-limiting)

---

## Ingestion API

Endpoints for document management.

### Upload Document

Upload and process a PDF document.

```
POST /ingest
```

**Request:**
- Content-Type: `multipart/form-data`
- Body: PDF file (max 50MB)

**cURL Example:**
```bash
curl -X POST "http://localhost:7860/ingest" \
  -H "X-API-Key: your_api_key" \
  -F "file=@document.pdf"
```

**Python Example:**
```python
import requests

with open("document.pdf", "rb") as f:
    response = requests.post(
        "http://localhost:7860/ingest",
        files={"file": ("document.pdf", f, "application/pdf")},
        headers={"X-API-Key": "your_api_key"}
    )
print(response.json())
```

**Response (200 OK):**
```json
{
  "document_id": "a4aee82f18829911",
  "filename": "document.pdf",
  "chunks": 42,
  "pages": 10,
  "message": "Document ingested: 42 chunks embedded and stored"
}
```

**Errors:**
| Status | Description |
|--------|-------------|
| 400 | Invalid file type (not PDF) |
| 400 | Empty file |
| 400 | File too large (>50MB) |
| 400 | No text content found |
| 500 | Processing error |

---

### List Documents

Get all ingested documents.

```
GET /ingest/documents
```

**cURL Example:**
```bash
curl "http://localhost:7860/ingest/documents" \
  -H "X-API-Key: your_api_key"
```

**Response (200 OK):**
```json
{
  "documents": [
    {
      "document_id": "a4aee82f18829911",
      "filename": "research_paper.pdf"
    },
    {
      "document_id": "b5bff93g29930022",
      "filename": "technical_manual.pdf"
    }
  ],
  "total": 2
}
```

---

### Delete Document

Delete a document and all its chunks.

```
DELETE /ingest/{document_id}
```

**Parameters:**
| Name | Type | Description |
|------|------|-------------|
| document_id | string | Document ID to delete |

**cURL Example:**
```bash
curl -X DELETE "http://localhost:7860/ingest/a4aee82f18829911" \
  -H "X-API-Key: your_api_key"
```

**Response (200 OK):**
```json
{
  "message": "Document 'a4aee82f18829911' deleted"
}
```

---

### Clear All Documents

Delete all documents from the knowledge base.

```
POST /ingest/clear
```

**cURL Example:**
```bash
curl -X POST "http://localhost:7860/ingest/clear" \
  -H "X-API-Key: your_api_key"
```

**Response (200 OK):**
```json
{
  "message": "Vector store cleared"
}
```

---

### Get Page Text

Get full text content of a specific page (for highlighting).

```
GET /ingest/documents/{document_id}/page/{page_number}/text
```

**Parameters:**
| Name | Type | Description |
|------|------|-------------|
| document_id | string | Document ID |
| page_number | integer | Page number (1-indexed) |

**cURL Example:**
```bash
curl "http://localhost:7860/ingest/documents/a4aee82f18829911/page/3/text"
```

**Response (200 OK):**
```json
{
  "document_id": "a4aee82f18829911",
  "page_number": 3,
  "text": "Full text content of page 3...",
  "chunk_count": 4
}
```

---

### Ingestion Status

Get service status and configuration.

```
GET /ingest/status
```

**Response (200 OK):**
```json
{
  "status": "ready",
  "chunk_size": 512,
  "chunk_overlap": 50,
  "embedding_model": "all-MiniLM-L6-v2",
  "embedding_dimension": 384,
  "collection": {
    "name": "rag_documents",
    "vectors_count": 156,
    "points_count": 156
  }
}
```

---

## Query API

Endpoints for search and question answering.

### RAG Question Answering

Ask a question and get an AI-generated answer with sources.

```
POST /query/ask
```

**Request Body:**
```json
{
  "question": "What are the main findings of the study?",
  "top_k": 5,
  "document_id": null,
  "document_ids": ["a4aee82f18829911"],
  "temperature": 0.3
}
```

**Parameters:**
| Name | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| question | string | Yes | - | Question to answer (1-2000 chars) |
| top_k | integer | No | 5 | Number of chunks to retrieve (1-20) |
| document_id | string | No | null | Filter by single document (deprecated) |
| document_ids | array | No | null | Filter by multiple documents |
| temperature | float | No | 0.3 | LLM temperature (0.0-1.0) |

**cURL Example:**
```bash
curl -X POST "http://localhost:7860/query/ask" \
  -H "Content-Type: application/json" \
  -H "X-API-Key: your_api_key" \
  -d '{
    "question": "What are the key conclusions?",
    "document_ids": ["a4aee82f18829911"],
    "top_k": 5
  }'
```

**Python Example:**
```python
import requests

response = requests.post(
    "http://localhost:7860/query/ask",
    json={
        "question": "What methodology was used?",
        "document_ids": ["a4aee82f18829911", "b5bff93g29930022"],
        "top_k": 10,
        "temperature": 0.2
    }
)
result = response.json()
print(f"Answer: {result['answer']}")
for source in result['sources']:
    print(f"  - Page {source['page_number']}: {source['text_preview'][:100]}...")
```

**Response (200 OK):**
```json
{
  "question": "What are the key conclusions?",
  "answer": "Based on the documents, the key conclusions are:\n\n1. The proposed method achieves 95% accuracy...\n2. Performance improvements of 23% were observed...\n\n[Source 1, Source 2]",
  "sources": [
    {
      "source_id": 1,
      "document_id": "a4aee82f18829911",
      "page_number": 8,
      "text_preview": "Our experimental results demonstrate that the proposed approach achieves state-of-the-art performance...",
      "relevance_score": 0.892,
      "char_start": 3420,
      "char_end": 3890
    },
    {
      "source_id": 2,
      "document_id": "a4aee82f18829911",
      "page_number": 9,
      "text_preview": "In conclusion, we have presented a novel method that significantly improves...",
      "relevance_score": 0.856,
      "char_start": 0,
      "char_end": 445
    }
  ],
  "model": "llama-3.3-70b-versatile"
}
```

---

### Semantic Search

Search for relevant chunks without generating an answer.

```
POST /query/search
```

**Request Body:**
```json
{
  "query": "machine learning optimization",
  "top_k": 10,
  "score_threshold": 0.5,
  "document_id": null,
  "document_ids": null
}
```

**Parameters:**
| Name | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| query | string | Yes | - | Search query (1-1000 chars) |
| top_k | integer | No | 5 | Number of results (1-20) |
| score_threshold | float | No | 0.0 | Minimum similarity score (0.0-1.0) |
| document_id | string | No | null | Filter by single document |
| document_ids | array | No | null | Filter by multiple documents |

**cURL Example:**
```bash
curl -X POST "http://localhost:7860/query/search" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "neural network architecture",
    "top_k": 5,
    "score_threshold": 0.6
  }'
```

**Response (200 OK):**
```json
{
  "query": "neural network architecture",
  "results": [
    {
      "chunk_id": "a4aee82f18829911_0012",
      "document_id": "a4aee82f18829911",
      "text": "The neural network architecture consists of three main components: an encoder, a decoder, and an attention mechanism...",
      "page_number": 4,
      "score": 0.923,
      "char_start": 1560,
      "char_end": 2104,
      "metadata": {
        "filename": "research_paper.pdf",
        "chunk_index": 12
      }
    }
  ],
  "total": 1
}
```

---

### Semantic Search (GET)

Convenience GET endpoint for search.

```
GET /query/search?q={query}&top_k={top_k}&score_threshold={threshold}
```

**Query Parameters:**
| Name | Type | Required | Default | Description |
|------|------|----------|---------|-------------|
| q | string | Yes | - | Search query |
| top_k | integer | No | 5 | Number of results |
| score_threshold | float | No | 0.0 | Minimum score |
| document_id | string | No | null | Filter by document |

**cURL Example:**
```bash
curl "http://localhost:7860/query/search?q=deep%20learning&top_k=10"
```

---

## Health API

Endpoints for monitoring service health.

### Health Check

Basic health check.

```
GET /health
```

**Response (200 OK):**
```json
{
  "status": "healthy"
}
```

---

### Readiness Check

Detailed readiness check with dependency status.

```
GET /ready
```

**Response (200 OK):**
```json
{
  "status": "healthy",
  "checks": {
    "vector_store": true,
    "embeddings": true
  }
}
```

**Response (200 OK - Degraded):**
```json
{
  "status": "degraded",
  "checks": {
    "vector_store": false,
    "embeddings": true
  }
}
```

---

## Error Handling

All errors return a consistent JSON format.

### Error Response Format

```json
{
  "error": "Error message",
  "detail": "Additional details (optional)"
}
```

### HTTP Status Codes

| Status | Description |
|--------|-------------|
| 200 | Success |
| 400 | Bad Request - Invalid input |
| 401 | Unauthorized - Invalid/missing API key |
| 404 | Not Found - Resource doesn't exist |
| 422 | Validation Error - Invalid request body |
| 429 | Too Many Requests - Rate limit exceeded |
| 500 | Internal Server Error |
| 503 | Service Unavailable - LLM provider error |

### Validation Error Example

```json
{
  "error": "Validation error",
  "detail": [
    {
      "loc": ["body", "question"],
      "msg": "field required",
      "type": "value_error.missing"
    }
  ]
}
```

---

## Rate Limiting

API endpoints are rate limited to prevent abuse.

### Default Limits

- 100 requests per minute per IP
- 10 concurrent requests per IP

### Rate Limit Response

When rate limit is exceeded:

```
HTTP/1.1 429 Too Many Requests
Retry-After: 60
```

```json
{
  "error": "Rate limit exceeded",
  "detail": "Too many requests. Please retry after 60 seconds."
}
```

### Headers

Rate limit information is included in response headers:

```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1704067200
```

---

## SDK Examples

### Python SDK

```python
class EnterpriseRAGClient:
    def __init__(self, base_url: str, api_key: str = None):
        self.base_url = base_url.rstrip("/")
        self.headers = {}
        if api_key:
            self.headers["X-API-Key"] = api_key
    
    def ingest(self, filepath: str) -> dict:
        with open(filepath, "rb") as f:
            response = requests.post(
                f"{self.base_url}/ingest",
                files={"file": f},
                headers=self.headers
            )
        response.raise_for_status()
        return response.json()
    
    def ask(self, question: str, document_ids: list = None, top_k: int = 5) -> dict:
        response = requests.post(
            f"{self.base_url}/query/ask",
            json={
                "question": question,
                "document_ids": document_ids,
                "top_k": top_k
            },
            headers={**self.headers, "Content-Type": "application/json"}
        )
        response.raise_for_status()
        return response.json()
    
    def search(self, query: str, top_k: int = 10) -> dict:
        response = requests.post(
            f"{self.base_url}/query/search",
            json={"query": query, "top_k": top_k},
            headers={**self.headers, "Content-Type": "application/json"}
        )
        response.raise_for_status()
        return response.json()

# Usage
client = EnterpriseRAGClient("http://localhost:7860", api_key="your_key")
doc = client.ingest("paper.pdf")
answer = client.ask("What is the main contribution?", document_ids=[doc["document_id"]])
print(answer["answer"])
```

### JavaScript/TypeScript

```typescript
class EnterpriseRAGClient {
  constructor(
    private baseUrl: string,
    private apiKey?: string
  ) {}

  private get headers(): HeadersInit {
    const headers: HeadersInit = { "Content-Type": "application/json" };
    if (this.apiKey) headers["X-API-Key"] = this.apiKey;
    return headers;
  }

  async ingest(file: File): Promise<IngestResponse> {
    const formData = new FormData();
    formData.append("file", file);
    
    const response = await fetch(`${this.baseUrl}/ingest`, {
      method: "POST",
      headers: this.apiKey ? { "X-API-Key": this.apiKey } : {},
      body: formData,
    });
    return response.json();
  }

  async ask(question: string, documentIds?: string[]): Promise<AskResponse> {
    const response = await fetch(`${this.baseUrl}/query/ask`, {
      method: "POST",
      headers: this.headers,
      body: JSON.stringify({ question, document_ids: documentIds }),
    });
    return response.json();
  }

  async search(query: string, topK = 10): Promise<SearchResponse> {
    const response = await fetch(`${this.baseUrl}/query/search`, {
      method: "POST",
      headers: this.headers,
      body: JSON.stringify({ query, top_k: topK }),
    });
    return response.json();
  }
}

// Usage
const client = new EnterpriseRAGClient("http://localhost:7860", "your_key");
const doc = await client.ingest(fileInput.files[0]);
const answer = await client.ask("What is this about?", [doc.document_id]);
console.log(answer.answer);
```

---

## OpenAPI Specification

Full OpenAPI 3.0 specification is available at:

```
GET /openapi.json
```

Interactive documentation (when DEBUG=true):

- Swagger UI: `/docs`
- ReDoc: `/redoc`

---

<p align="center">
  📚 Enterprise RAG API v1.0.0
</p>
