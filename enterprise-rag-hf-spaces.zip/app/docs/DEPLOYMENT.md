# 🚀 Deployment Guide

Complete guide for deploying Enterprise RAG to various platforms.

## Table of Contents

- [Hugging Face Spaces](#hugging-face-spaces-free)
- [Docker](#docker-self-hosted)
- [Railway](#railway)
- [Render](#render)
- [AWS](#aws)
- [Production Checklist](#production-checklist)

---

## Hugging Face Spaces (Free)

Best for: Quick demos, free hosting, easy sharing

### Prerequisites

- Hugging Face account (free)
- Groq API key (free at https://console.groq.com)

### Step-by-Step Deployment

#### 1. Create Hugging Face Account

1. Go to https://huggingface.co/join
2. Sign up with email or GitHub
3. Verify your email

#### 2. Get LLM API Key

**Groq (Recommended - Free)**
1. Go to https://console.groq.com
2. Sign up / Log in
3. Navigate to API Keys
4. Create new API key
5. Copy and save securely

**Alternative Providers:**
- OpenAI: https://platform.openai.com/api-keys
- Anthropic: https://console.anthropic.com
- Google AI: https://makersuite.google.com/app/apikey

#### 3. Create New Space

1. Go to https://huggingface.co/new-space
2. Fill in the form:
   - **Owner**: Your username
   - **Space name**: `enterprise-rag`
   - **License**: MIT
   - **SDK**: Select **Docker**
   - **Docker Template**: Blank
   - **Hardware**: CPU basic (free tier)
   - **Visibility**: Public or Private
3. Click **Create Space**

#### 4. Upload Files

**Option A: Git (Recommended)**

```bash
# Install Git LFS (if not installed)
git lfs install

# Clone your space
git clone https://huggingface.co/spaces/YOUR_USERNAME/enterprise-rag
cd enterprise-rag

# Extract deployment files
unzip enterprise-rag-hf-spaces.zip -d .

# Verify structure
ls -la
# Should show: app/, main.py, Dockerfile, README.md, requirements.txt

# Push to Hugging Face
git add .
git commit -m "Initial deployment"
git push
```

**Option B: Web Interface**

1. In your Space, click **Files** tab
2. Click **+ Add file** → **Upload files**
3. Extract zip locally first
4. Drag and drop all files:
   - `app/` folder (with all subfolders)
   - `main.py`
   - `Dockerfile`
   - `README.md`
   - `requirements.txt`
5. Click **Commit changes**

#### 5. Configure Secrets

1. Go to your Space → **Settings** tab
2. Scroll to **Variables and secrets**
3. Click **New secret**
4. Add required secrets:

| Name | Value | Required |
|------|-------|----------|
| `GROQ_API_KEY` | Your Groq API key | Yes |
| `DEBUG` | `false` | No |

5. Click **Save** for each secret

#### 6. Monitor Build

1. Go to **App** tab
2. Watch build logs
3. Build takes 3-5 minutes
4. Look for "Running on http://0.0.0.0:7860"

#### 7. Access Your App

Your app is live at:
```
https://YOUR_USERNAME-enterprise-rag.hf.space
```

### Troubleshooting HF Spaces

**Build fails with "No space left on device"**
- Free tier has limited disk space
- Remove unnecessary files from repository

**App crashes on startup**
- Check logs in App tab
- Verify all secrets are set
- Ensure GROQ_API_KEY is valid

**"Application error" after build**
- Check if port 7860 is used in Dockerfile
- Verify main.py exists at root level

---

## Docker (Self-hosted)

Best for: Full control, custom infrastructure, air-gapped environments

### Basic Docker Run

```bash
# Build image
docker build -t enterprise-rag .

# Run with in-memory storage
docker run -d \
  --name enterprise-rag \
  -p 7860:7860 \
  -e GROQ_API_KEY=your_groq_key \
  enterprise-rag

# Check logs
docker logs -f enterprise-rag
```

### Docker with Persistent Storage

Using Qdrant Cloud:

```bash
docker run -d \
  --name enterprise-rag \
  -p 7860:7860 \
  -e GROQ_API_KEY=your_groq_key \
  -e QDRANT_URL=https://xxx.cloud.qdrant.io:6333 \
  -e QDRANT_API_KEY=your_qdrant_key \
  -e QDRANT_IN_MEMORY=false \
  enterprise-rag
```

Using local Qdrant:

```bash
# Start Qdrant
docker run -d \
  --name qdrant \
  -p 6333:6333 \
  -v qdrant_storage:/qdrant/storage \
  qdrant/qdrant

# Start RAG app
docker run -d \
  --name enterprise-rag \
  -p 7860:7860 \
  --link qdrant \
  -e GROQ_API_KEY=your_groq_key \
  -e QDRANT_HOST=qdrant \
  -e QDRANT_PORT=6333 \
  -e QDRANT_IN_MEMORY=false \
  enterprise-rag
```

### Docker Compose

```yaml
# docker-compose.yml
version: '3.8'

services:
  qdrant:
    image: qdrant/qdrant:latest
    ports:
      - "6333:6333"
    volumes:
      - qdrant_storage:/qdrant/storage
    restart: unless-stopped

  rag:
    build: .
    ports:
      - "7860:7860"
    environment:
      - GROQ_API_KEY=${GROQ_API_KEY}
      - QDRANT_HOST=qdrant
      - QDRANT_PORT=6333
      - QDRANT_IN_MEMORY=false
      - DEBUG=false
    depends_on:
      - qdrant
    restart: unless-stopped

volumes:
  qdrant_storage:
```

Run with:
```bash
# Create .env file
echo "GROQ_API_KEY=your_key" > .env

# Start services
docker-compose up -d

# View logs
docker-compose logs -f rag
```

---

## Railway

Best for: Easy deployment, automatic SSL, GitHub integration

### Deploy to Railway

1. Go to https://railway.app
2. Click **New Project** → **Deploy from GitHub repo**
3. Connect your repository
4. Add environment variables:
   - `GROQ_API_KEY`
   - `PORT=7860`
5. Railway auto-detects Dockerfile
6. Deploy!

### railway.json (Optional)

```json
{
  "$schema": "https://railway.app/railway.schema.json",
  "build": {
    "builder": "DOCKERFILE",
    "dockerfilePath": "Dockerfile"
  },
  "deploy": {
    "startCommand": "uvicorn main:app --host 0.0.0.0 --port $PORT",
    "healthcheckPath": "/health",
    "restartPolicyType": "ON_FAILURE"
  }
}
```

---

## Render

Best for: Free tier, automatic deploys, managed infrastructure

### Deploy to Render

1. Go to https://render.com
2. Click **New** → **Web Service**
3. Connect GitHub repository
4. Configure:
   - **Environment**: Docker
   - **Plan**: Free (or paid for more resources)
5. Add environment variables
6. Deploy

### render.yaml

```yaml
services:
  - type: web
    name: enterprise-rag
    env: docker
    plan: free
    healthCheckPath: /health
    envVars:
      - key: GROQ_API_KEY
        sync: false
      - key: PORT
        value: 7860
```

---

## AWS

Best for: Enterprise deployments, scalability, existing AWS infrastructure

### AWS ECS with Fargate

```bash
# Create ECR repository
aws ecr create-repository --repository-name enterprise-rag

# Build and push image
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin YOUR_ACCOUNT.dkr.ecr.us-east-1.amazonaws.com
docker build -t enterprise-rag .
docker tag enterprise-rag:latest YOUR_ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/enterprise-rag:latest
docker push YOUR_ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/enterprise-rag:latest
```

### Task Definition (task-definition.json)

```json
{
  "family": "enterprise-rag",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "1024",
  "memory": "4096",
  "containerDefinitions": [
    {
      "name": "rag",
      "image": "YOUR_ACCOUNT.dkr.ecr.us-east-1.amazonaws.com/enterprise-rag:latest",
      "portMappings": [
        {
          "containerPort": 7860,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {"name": "PORT", "value": "7860"}
      ],
      "secrets": [
        {
          "name": "GROQ_API_KEY",
          "valueFrom": "arn:aws:secretsmanager:us-east-1:YOUR_ACCOUNT:secret:groq-api-key"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/enterprise-rag",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ]
}
```

---

## Production Checklist

### Security

- [ ] Set `API_KEY` environment variable for endpoint protection
- [ ] Use HTTPS (handled by most platforms)
- [ ] Restrict CORS origins in production
- [ ] Store secrets securely (not in code)
- [ ] Enable rate limiting (already included)

### Performance

- [ ] Use Qdrant Cloud or self-hosted Qdrant for persistence
- [ ] Allocate minimum 4GB RAM for embedding model
- [ ] Consider GPU instance for faster embeddings (optional)
- [ ] Enable response caching for frequent queries

### Monitoring

- [ ] Set up log aggregation
- [ ] Monitor `/health` and `/ready` endpoints
- [ ] Set up alerts for error rates
- [ ] Track API latency metrics

### Backup

- [ ] Regular Qdrant snapshots (if self-hosted)
- [ ] Document backup procedures
- [ ] Test restore process

### Environment Variables for Production

```env
# Required
GROQ_API_KEY=your_production_key

# Security
API_KEY=strong_random_api_key
CORS_ORIGINS=https://yourdomain.com

# Performance
DEBUG=false

# Persistence (Qdrant Cloud recommended)
QDRANT_URL=https://xxx.cloud.qdrant.io:6333
QDRANT_API_KEY=your_qdrant_key
QDRANT_IN_MEMORY=false

# Optional tuning
CHUNK_SIZE=512
CHUNK_OVERLAP=50
EMBEDDING_MODEL=all-MiniLM-L6-v2
```

---

## Getting Help

- **Issues**: Open a GitHub issue
- **Discussions**: Use GitHub Discussions
- **Security**: Email security@yourdomain.com

---

<p align="center">
  Happy Deploying! 🚀
</p>
