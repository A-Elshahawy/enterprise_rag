"""Health check endpoints."""

from fastapi import APIRouter

router = APIRouter(tags=["health"])


@router.get("/health")
async def health_check() -> dict:
    """Basic health check."""
    return {"status": "healthy"}


@router.get("/ready")
async def readiness_check() -> dict:
    """Readiness check with dependencies."""
    from app.core.vector_store import get_vector_store
    from app.core.embeddings import get_embedding_service
    
    checks = {"vector_store": False, "embeddings": False}
    
    try:
        vs = get_vector_store()
        vs.ensure_collection()
        checks["vector_store"] = True
    except Exception:
        pass
    
    try:
        es = get_embedding_service()
        _ = es.dimension
        checks["embeddings"] = True
    except Exception:
        pass
    
    status = "healthy" if all(checks.values()) else "degraded"
    return {"status": status, "checks": checks}
