"""Middleware for the application."""

import logging
import time
import uuid
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request

from app.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class RequestIDMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4())[:8])
        request.state.request_id = request_id
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response


class LoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start = time.time()
        response = await call_next(request)
        duration = time.time() - start
        
        if not request.url.path.startswith("/health"):
            logger.info(
                f"{request.method} {request.url.path} - {response.status_code} ({duration:.3f}s)"
            )
        return response


class APIKeyMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Skip auth for health checks and static files
        if request.url.path in ["/health", "/ready", "/", "/docs", "/redoc", "/openapi.json"]:
            return await call_next(request)
        if request.url.path.startswith("/static"):
            return await call_next(request)
        
        # Check API key if configured
        if settings.api_key:
            api_key = request.headers.get("X-API-Key")
            if api_key != settings.api_key:
                from fastapi.responses import JSONResponse
                return JSONResponse(
                    status_code=401,
                    content={"error": "Invalid or missing API key"}
                )
        
        return await call_next(request)
